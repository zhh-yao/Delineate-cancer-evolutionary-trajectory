# In[1]:

import numpy as np
import pandas as pd


# In[2]:

def dataImport(Patient, Pattern, agent, keys, time):
        
    all_mat = pd.DataFrame(np.load('Pt%s_%d_%d.npy'%(Patient, Pattern, agent), allow_pickle=True).item(), columns=keys)
    
    mat = all_mat.iloc[time]      
    
    return mat

'''
def piePlot(Patients, keys):
    
    n = len(Patients)
    colors = ['thistle','#FBA07E','yellowgreen','#72AC4C','lightskyblue','darkseagreen','#FCCC2E','tomato','violet','#7C99D2','peru','khaki','#F197B7','orange','#F5DEB3','tan']

    fig, axs = plt.subplots(1, n)
    for i in range(n):
        data = dataImport(Patients[i], 0, keys, 0).values
        #axs[i].pie(data, colors, autopct='%1.1f%%', shadow=True)
        axs[i](aspect='equal')
        axs[i].pie(data, autopct='%1.1f%%', shadow=True)
'''   

# In[3]:

keys = ['D:0.0,R:0.9,P:0.1',
        'D:0.0,R:1.0,P:0.0',
        'D:0.1,R:0.7,P:0.2',
        'D:0.1,R:0.8,P:0.1',
        'D:0.1,R:0.9,P:0.0',
        'D:0.2,R:0.5,P:0.3',
        'D:0.2,R:0.6,P:0.2',
        'D:0.2,R:0.7,P:0.1',
        'D:0.3,R:0.3,P:0.4',
        'D:0.3,R:0.4,P:0.3',
        'D:0.3,R:0.5,P:0.2',
        'D:0.4,R:0.1,P:0.5',
        'D:0.4,R:0.2,P:0.4',
        'D:0.4,R:0.3,P:0.3',
        'D:0.5,R:0.0,P:0.5',
        'D:0.5,R:0.1,P:0.4']


data = dataImport('039', 1, 0, keys, 0).values
data = dataImport('039', 1, 1, keys, 0).values
data = dataImport('039', 1, 2, keys, 0).values
data = dataImport('039', 1, 3, keys, 0).values
data = dataImport('039', 1, 4, keys, 0).values


data = dataImport('039', 2, 0, keys, 0).values
data = dataImport('039', 2, 1, keys, 0).values
data = dataImport('039', 2, 2, keys, 0).values
data = dataImport('039', 2, 3, keys, 0).values
data = dataImport('039', 2, 4, keys, 0).values


data = dataImport('039', 3, 0, keys, 0).values
data = dataImport('039', 3, 1, keys, 0).values
data = dataImport('039', 3, 2, keys, 0).values
data = dataImport('039', 3, 3, keys, 0).values
data = dataImport('039', 3, 4, keys, 0).values



data = dataImport('058', 1, 0, keys, 0).values
data = dataImport('058', 1, 1, keys, 0).values
data = dataImport('058', 1, 2, keys, 0).values
data = dataImport('058', 1, 3, keys, 0).values
data = dataImport('058', 1, 4, keys, 0).values


data = dataImport('058', 2, 0, keys, 0).values
data = dataImport('058', 2, 1, keys, 0).values
data = dataImport('058', 2, 2, keys, 0).values
data = dataImport('058', 2, 3, keys, 0).values
data = dataImport('058', 2, 4, keys, 0).values


data = dataImport('058', 3, 0, keys, 0).values
data = dataImport('058', 3, 1, keys, 0).values
data = dataImport('058', 3, 2, keys, 0).values
data = dataImport('058', 3, 3, keys, 0).values
data = dataImport('058', 3, 4, keys, 0).values



data = dataImport('081', 1, 0, keys, 0).values
data = dataImport('081', 1, 1, keys, 0).values
data = dataImport('081', 1, 2, keys, 0).values
data = dataImport('081', 1, 3, keys, 0).values
data = dataImport('081', 1, 4, keys, 0).values


data = dataImport('081', 2, 0, keys, 0).values
data = dataImport('081', 2, 1, keys, 0).values
data = dataImport('081', 2, 2, keys, 0).values
data = dataImport('081', 2, 3, keys, 0).values
data = dataImport('081', 2, 4, keys, 0).values


data = dataImport('081', 3, 0, keys, 0).values
data = dataImport('081', 3, 1, keys, 0).values
data = dataImport('081', 3, 2, keys, 0).values
data = dataImport('081', 3, 3, keys, 0).values
data = dataImport('081', 3, 4, keys, 0).values






