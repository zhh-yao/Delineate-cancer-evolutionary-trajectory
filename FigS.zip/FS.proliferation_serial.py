# In[1]:

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


# In[2]: 

def dataImport(Pattern, agent, keys):
    
    mat = pd.DataFrame(np.load('%s\clone_%s_%d.npy'%(Pattern, Pattern, agent), allow_pickle=True).item(), columns=keys)
                
    return mat


def prolifCalculate(mat, time):
    
    prolif = 0
    data = mat.loc[time]
    
    for i in range(len(data)):
        prolif += float(data.index[i][14:17]) * data[i]
        
    prolif = prolif/sum(data)

    return prolif


def prolifMatrix(Pattern, keys, allAgent, allCycle):
    
    proMat = np.empty((allAgent, allCycle), dtype=float)
    
    for agent in range(allAgent):
        
        mat = dataImport(Pattern, agent, keys)
        
        prolifCalculate(mat, time)
        
    return proMat



.plot(x, Y.T, color="C0", alpha=0.1)






